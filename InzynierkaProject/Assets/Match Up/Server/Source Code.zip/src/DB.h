#ifndef __DB_H__
#define __DB_H__

#include "sqlite/sqlite3.h"
#include <iostream>
#include "Debug.h"

using namespace std;

/**
 * Some convenient methods for working with the sqlite database
 */
class DB
{
public:

  static void BeginTransaction(sqlite3* db)
  {
    Exec(db, "BEGIN TRANSACTION", "Starting transaction");
  }
  
  static void EndTransaction(sqlite3* db)
  {
    Exec(db, "END TRANSACTION", "Ending transaction");
  }

  static void RollbackTransaction(sqlite3* db)
  {
    Exec(db, "ROLLBACK", "Rolling back transaction");
  }
  
  static void Exec(sqlite3* db, string q, string context)
  {
    char* err;
    sqlite3_exec(db, &q[0], NULL, 0, &err);
    if (err) 
    {
      Debug::SqlError(err);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Prepare an sql statement. Print an error and finalize the statement if it fails.
   */
  static void Prep(sqlite3* db, sqlite3_stmt** st, string query, string context)
  {
    int result = sqlite3_prepare_v2(db, query.c_str(), -1, st, NULL);
    if (result != SQLITE_OK)
    {
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Execute an sql statement / fetch one row. Print an error and finalize the statement if the query fails.
   */
  static void Step(sqlite3* db, sqlite3_stmt* st, string context, int* resultCode = NULL, bool finalizeOnError = false)
  {
    int result = sqlite3_step(st);
    if (resultCode != NULL)
    {
      *resultCode = result;
    }
    if (result != SQLITE_OK && result != SQLITE_DONE && result != SQLITE_ROW)
    {
      if (finalizeOnError) sqlite3_finalize(st);
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Bind an parameter to a prepared statement. Print an error and finalize the statement if binding fails.
   */
  static void Bind(sqlite3* db, sqlite3_stmt* st, int bindPos, long long value, string context, bool finalizeOnError = false)
  {
    int result = sqlite3_bind_int64(st, bindPos, (sqlite3_int64)value);
    if (result != SQLITE_OK)
    {
      if (finalizeOnError) sqlite3_finalize(st);
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Bind an paremeter to a prepared statemnt. Print an error and finalize the statement if binding fails.
   */
  static void Bind(sqlite3* db, sqlite3_stmt* st, int bindPos, int value, string context, bool finalizeOnError = false)
  {
    int result = sqlite3_bind_int(st, bindPos, value);
    if (result != SQLITE_OK)
    {
      if (finalizeOnError) sqlite3_finalize(st);
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Bind an paremeter to a prepared statemnt. Print an error and finalize the statement if binding fails.
   */
  static void Bind(sqlite3* db, sqlite3_stmt* st, int bindPos, double value, string context, bool finalizeOnError = false)
  {
    int result = sqlite3_bind_double(st, bindPos, value);
    if (result != SQLITE_OK)
    {
      if (finalizeOnError) sqlite3_finalize(st);
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }

  /**
   * Bind an paremeter to a prepared statemnt. Print an error and finalize the statement if binding fails.
   */
  static void Bind(sqlite3* db, sqlite3_stmt* st, int bindPos, string& value, string context, bool finalizeOnError = false)
  {
    int result = sqlite3_bind_text(st, bindPos, value.c_str(), -1, SQLITE_TRANSIENT);
    if (result != SQLITE_OK)
    {
      if (finalizeOnError) sqlite3_finalize(st);
      Debug::SqlError(result, db, context);
      throw std::runtime_error("sql error: " + context);
    }
  }
};

#endif
