#ifndef __SERVER_H__
#define __SERVER_H__

#if _WIN32 || _WIN64
#include <WinSock2.h>
#include <WS2tcpip.h>
//#include <Windows.h>
#pragma comment(lib, "ws2_32")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#endif

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <string>
#include <unistd.h>

using namespace std;

/**
 * Just your standard multithreaded socket server.
 * Supports IPv6.
 */
class Server 
{

  private:
    //Socket stuff
	  int serverSocks[FD_SETSIZE];
    int clientSock;
	  int numServerSocks;
    short port;
	  bool shuttingDown = false;
	  #if _WIN32 || _WIN64
		  SOCKADDR_STORAGE serverAddr, clientAddr;
	  #else
		  struct sockaddr_in6 serverAddr, clientAddr;
	  #endif
    char buffer[4096];
    int epollFD = -1;
    std::function<void(int)> socketDisconnectHandler;
    std::function<string(string, int)> socketReceiveHandler;

  public:
    /**
     * Create a new server listening on the specified port and IP.
     * If no IP is specified it will listen on all.
     */
    Server(string* ip, int ipCount, short port, std::function<string(string, int)> socketReceiveHandler, std::function<void(int)> onSocketDisconnect);

    /**
     * Clean up the clients and cancel their threads
     */
    void CleanUp();

    /**
     * Loop forever listening for incoming connections.
     */
    void AcceptAndDispatch();

	  void DisconnectClient(int socketID);

    /**
     * Whenever a connection is made a new thread is started
     * to listen for incoming data on that connection.
     */
    void HandleClient(int socketID);

    /**
     * Send a message to a specific client identified by their socketID.
     */
    void SendToClient(int socketID, string message);
};

#endif
