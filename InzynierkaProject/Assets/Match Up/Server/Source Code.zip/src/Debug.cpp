#include "Debug.h"

bool Debug::isVerbose = false;
