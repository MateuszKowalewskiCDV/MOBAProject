#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <iostream>
#include <string>
#include "sqlite/sqlite3.h"

using namespace std;

/**
 * Some useful methods for printing. Includes an isVerbose flag
 * to easily control the level of output.
 */
class Debug
{
public:
  static bool isVerbose;

  /**
   * Basic log message. Does nothing unless isVerbose or isCritical are true.
   */
  static void Log(string msg, bool isCritical = false)
  {
    if (!isVerbose && !isCritical) return;

    // Intentionally using printf instead of cout to avoid GLIBCXX_3.4.9 dependence
    printf("%s\n", msg.c_str());
  }

  /**
   * A log message that is always critical
   * The same as Log(msg, true)
   */
  static void Error(string msg)
  {
    Log(msg, true);
  }

  /**
   * Print out an sql error and then free the error memory
   */
  static void SqlError(char* error)
  {
    if (error == NULL) return;

    Log("Sql Error: " + string(error), true);
    sqlite3_free(error);
  }

  /**
   * Print out an sql error with an error code and a custom string.
   */
  static void SqlError(int errorCode, sqlite3* db, string customMessage = "")
  {
    const char* errorMessage = sqlite3_errmsg(db);
    Log("Sql Error: (" + to_string((long long)errorCode) + "): " + customMessage + "\n\t" + string(errorMessage), true);
  }
  
};

#endif
