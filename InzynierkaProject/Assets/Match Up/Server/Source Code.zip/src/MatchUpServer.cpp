#include "MatchUpServer.h"
#include "Debug.h"
#include "DB.h"
#include "Server.h"

using namespace std;

Server* MatchUpServer::server = NULL;
sqlite3* MatchUpServer::db = NULL;
sqlite3_stmt* MatchUpServer::queryGetMatch = NULL;
sqlite3_stmt* MatchUpServer::queryCreateMatch = NULL;
sqlite3_stmt* MatchUpServer::queryGetIntData = NULL;
sqlite3_stmt* MatchUpServer::queryGetFloatData = NULL;
sqlite3_stmt* MatchUpServer::queryGetStringData = NULL;
sqlite3_stmt* MatchUpServer::queryInsertIntData = NULL;
sqlite3_stmt* MatchUpServer::queryInsertFloatData = NULL;
sqlite3_stmt* MatchUpServer::queryInsertStringData = NULL;
sqlite3_stmt* MatchUpServer::queryDeleteIntData = NULL;
sqlite3_stmt* MatchUpServer::queryDeleteFloatData = NULL;
sqlite3_stmt* MatchUpServer::queryDeleteStringData = NULL;
sqlite3_stmt* MatchUpServer::queryAddClientToMatch = NULL;
sqlite3_stmt* MatchUpServer::querySetMatchHost = NULL;
sqlite3_stmt* MatchUpServer::queryDestroyMatch = NULL;
sqlite3_stmt* MatchUpServer::queryRemoveClientFromMatch = NULL;
sqlite3_stmt* MatchUpServer::queryDestroyMatchForSocket = NULL;
sqlite3_stmt* MatchUpServer::queryRemoveClientForSocket = NULL;
sqlite3_stmt* MatchUpServer::queryUpdateFilteredMatchData = NULL;
sqlite3_stmt* MatchUpServer::querySelectFilteredMatches = NULL;

const string MatchUpServer::COMMANDS[7] = {
  "Get Match",
  "Get Match List", 
  "Create Match", 
  "Destroy Match", 
  "Join Match", 
  "Leave Match", 
  "Set Match Data"
};

void MatchUpServer::StartServer(string* ip, int ipCount, int port, long long heapSize, string databaseName)
{
  sqlite3_soft_heap_limit64(heapSize);

  int rc = sqlite3_open_v2(databaseName.c_str(), &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, nullptr);
  if(rc)
  {
    Debug::Error("Can't open database");
  }

  // Create tables if they don't exist
  DB::Exec(db, "PRAGMA foreign_keys = on", "Enable foreign keys");
  DB::Exec(db, "PRAGMA journal_mode = MEMORY", "Setting journal_mode = MEMORY");

  string q;
  q = "CREATE TABLE IF NOT EXISTS Matches ("
    " id INTEGER primary key autoincrement,"
    " hostClientID int,"
    " name varchar(64),"
    " maxClients int,"
    " createdOn timestamp not null default current_timestamp"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");

  q = "CREATE TABLE IF NOT EXISTS FilteredMatches ("
    " id INTEGER primary key autoincrement,"
    " matchID INTEGER,"
    " matchData TEXT,"
    " numDatas INTEGER"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");

  q = "CREATE TABLE IF NOT EXISTS Clients ("
    " id INTEGER primary key autoincrement,"
    " socketID int not null,"
    " matchID int not null,"
    " createdOn timestamp not null default current_timestamp,"
    " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");

  q = "CREATE TABLE IF NOT EXISTS FloatData ("
    " matchID int not null,"
    " key char(64) not null,"
    " value float not null default 0,"
    " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,"
    " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");
  
  q = "CREATE INDEX matchIDFloatIndex ON FloatData(matchID)";
  DB::Exec(db, q, "Creating Table: Matches");

  q = "CREATE TABLE IF NOT EXISTS IntData ("
    " matchID int not null,"
    " key char(64) not null,"
    " value int not null default 0,"
    " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,"
    " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");
  
  q = "CREATE INDEX matchIDIntIndex ON IntData(matchID)";
  DB::Exec(db, q, "Creating Table: Matches");

  q = "CREATE TABLE IF NOT EXISTS StringData ("
    " matchID int not null,"
    " key char(64) not null,"
    " value varchar not null default \"\","
    " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,"
    " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE"
    ")";
  DB::Exec(db, q, "Creating Table: Matches");
  
  q = "CREATE INDEX matchIDStringIndex ON StringData(matchID)";
  DB::Exec(db, q, "Creating Table: Matches");

	q = "SELECT id FROM Matches WHERE MATCHES.id = ?";
	DB::Prep(db, &queryGetMatch, q, "GetMatch preparing sql statement");

  q = "INSERT INTO Matches (name, maxClients) VALUES (?, ?)";
  DB::Prep(db, &queryCreateMatch, q, "CreateMatch preparing sql statement");

  q = "SELECT key, value FROM IntData WHERE IntData.matchID = ?";
  DB::Prep(db, &queryGetIntData, q, "EncodeMatchData preparing sql statement");

  q = "SELECT key, value FROM FloatData WHERE FloatData.matchID = ?";
  DB::Prep(db, &queryGetFloatData, q, "EncodeMatchData preparing sql statement");

  q = "SELECT key, value FROM StringData WHERE StringData.matchID = ?";
  DB::Prep(db, &queryGetStringData, q, "EncodeMatchData preparing sql statement");

  q = "INSERT INTO Clients (matchID, socketID) VALUES (?, ?)";
  DB::Prep(db, &queryAddClientToMatch, q, "AddClientToMatch preparing sql statement");

  q = "UPDATE Matches SET hostClientID = ? WHERE id = ?";
  DB::Prep(db, &querySetMatchHost, q, "SetMatchHost preparing query");

  q = "INSERT INTO IntData (matchID, key, value) VALUES (?, ?, ?)";
  DB::Prep(db, &queryInsertIntData, q, "SetMatchData preparing sql statement");

  q = "INSERT INTO FloatData (matchID, key, value) VALUES (?, ?, ?)";
  DB::Prep(db, &queryInsertFloatData, q, "SetMatchData preparing sql statement");

  q = "INSERT INTO StringData (matchID, key, value) VALUES (?, ?, ?)";
  DB::Prep(db, &queryInsertStringData, q, "SetMatchData preparing sql statement");

  q = "DELETE FROM IntData WHERE matchID = ? AND key = ?";
  DB::Prep(db, &queryDeleteIntData, q, "DeleteConflictingMatchData preparing sql statement");

  q = "DELETE FROM FloatData WHERE matchID = ? AND key = ?";
  DB::Prep(db, &queryDeleteFloatData, q, "DeleteConflictingMatchData preparing sql statement");

  q = "DELETE FROM StringData WHERE matchID = ? AND key = ?";
  DB::Prep(db, &queryDeleteStringData, q, "DeleteConflictingMatchData preparing sql statement");

  q = "DELETE FROM Matches WHERE id = ?";
  DB::Prep(db, &queryDestroyMatch, q, "DestroyMatch preparing sql statement");

  q = "DELETE FROM Clients WHERE id = ?";
  DB::Prep(db, &queryRemoveClientFromMatch, q, "RemoveClientFromMatch preparing sql statement");

  q = "DELETE FROM Matches WHERE hostClientID IN (SELECT id FROM Clients WHERE socketID = ?)";
  DB::Prep(db, &queryDestroyMatchForSocket, q, "DestroyMatchForSocket preparing query");

  q = "DELETE FROM Clients WHERE socketID = ?";
  DB::Prep(db, &queryRemoveClientForSocket, q, "RemoveClientForSocket preparing query");

  string delim = "|";
  string intType = to_string((int)Filter::INT);
  string floatType = to_string((int)Filter::FLOAT);
  string stringType = to_string((int)Filter::STRING);
  string intDataFields = "'" + intType + ",' || key || ',' || value";
  string intQuery = "SELECT COALESCE(GROUP_CONCAT(" + intDataFields + ", '" + delim + "') || '" + delim + "', '') FROM IntData WHERE IntData.matchID = FilteredMatches.matchID";
  string floatDataFields = "'" + floatType + ",' || key || ',' || value";
  string floatQuery = "SELECT COALESCE(GROUP_CONCAT(" + floatDataFields + ", '" + delim + "') || '" + delim + "', '') FROM FloatData WHERE FloatData.matchID = FilteredMatches.matchID";
  string stringDataFields = "'" + stringType + ",' || key || ',\"' || value || '\"'"; 
  string stringQuery = "SELECT COALESCE(GROUP_CONCAT(" + stringDataFields + ", '" + delim + "') || '" + delim +"', '') FROM StringData WHERE StringData.matchID = FilteredMatches.matchID";
  q = "UPDATE FilteredMatches SET "
    "matchData = RTRIM((" + intQuery + ") || (" + floatQuery + ") || (" + stringQuery + "), '" + delim + "'), "
    "numDatas = "
      "(SELECT COUNT(*) FROM IntData WHERE IntData.matchID = FilteredMatches.matchID) + "
      "(SELECT COUNT(*) FROM FloatData WHERE FloatData.matchID = FilteredMatches.matchID) + "
      "(SELECT COUNT(*) FROM StringData WHERE StringData.matchID = FilteredMatches.matchID)";
  DB::Prep(db, &queryUpdateFilteredMatchData, q, "UpdateFilteredMatchData preparing query");

  q = "SELECT GROUP_CONCAT(matchID || ',' || '\"\"' || ',' || numDatas || '" + delim + "' || matchData, '" + delim + "') FROM FilteredMatches";
  DB::Prep(db, &querySelectFilteredMatches, q, "GetMatchList preparing filtered select statement");

  // Initialize server
  server = new Server(ip, ipCount, port, &HandleSocketReceive, &HandleSocketDisconnect);
  server->AcceptAndDispatch();
}

void MatchUpServer::CleanUp()
{
  sqlite3_close(db);
  server->CleanUp();
  delete server;
}

string MatchUpServer::HandleSocketReceive(string message, int socketID)
{
  string transactionID;

  string response = "";
  try 
  {
    response = ReceivedCommand(message, socketID, &transactionID);
  }
  catch (std::runtime_error& e)
  {
    Debug::Error("Error processing command: " + std::string(e.what()));
  }
  catch (...) 
  {
    Debug::Error("Error processing command");
  }
    
	if (transactionID == "")
	{
		response = response + "\n";
	}
	else
	{
		response = transactionID + "|" + response + "\n";
	}
  return response;
}

string MatchUpServer::ReceivedCommand(string messageString, int socketID, string* transactionID)
{
  int firstPipePos = messageString.find('|');
  string commandString = messageString.substr(0, firstPipePos);
  int secondPipePos = messageString.find('|', firstPipePos + 1);
  *transactionID = messageString.substr(firstPipePos + 1, secondPipePos - (firstPipePos + 1));
  string theRestOfTheMessage = messageString.substr(secondPipePos + 1);

  long long commandID = StringUtil::try_stol(commandString, "Parsing command ID");
  if (commandID == LONG_MAX) return "";
  Command command = (Command)commandID;

  Debug::Log("Received command [" + COMMANDS[(int)command] + "][" + *transactionID + "]: " + theRestOfTheMessage);

  // Route commands to appropriate methods
  switch(command)
  {
	  case GET_MATCH:
	    {
		    size_t start = 0;
		    size_t end = theRestOfTheMessage.find(",", start);
		    string matchIDString = theRestOfTheMessage.substr(start, end - start);
		    long long matchID = StringUtil::try_stol(matchIDString, "Pasing matchID");
		    if (matchID == LONG_MAX) return "";
		    start = end + 1;

        string result = GetMatch(db, matchID);
        return result;
	    }
    case GET_MATCH_LIST:
      {
        // Get the page number
        size_t start = 0;
        size_t end = theRestOfTheMessage.find(",", start);
		    string pageNumberStr = theRestOfTheMessage.substr(start, end - start);
        long long page = StringUtil::try_stol(pageNumberStr, "Parsing page number");
		    if (page == LONG_MAX) return "";
        start = end + 1;

        // Get the number of results per page
        end = theRestOfTheMessage.find(",", start);
		    string numResultsStr = theRestOfTheMessage.substr(start, end - start);
        long long resultsPerPage = StringUtil::try_stol(numResultsStr, "Parsing results per page");
		    if (resultsPerPage == LONG_MAX) return "";
        start = end + 1;
        
        // Get the flag that tells us whether or not to include match data in the results
        end = theRestOfTheMessage.find("|", start);
        if (end == string::npos) end = theRestOfTheMessage.length();
        string matchDataFlag = theRestOfTheMessage.substr(start, (end - start));
        long long includeMatchData = StringUtil::try_stol(matchDataFlag, "Parsing includeMatchData flag");
		    if (includeMatchData == LONG_MAX) return "";
        start = end + 1;
        
        vector<Filter> filters;
        if (start < theRestOfTheMessage.length())
        {
          // The rest of the message will be parsed as filters
          theRestOfTheMessage = theRestOfTheMessage.substr(start);
          
          // Get the filters
          filters = ParseFilters(theRestOfTheMessage);
        }

        // Finally get the actual match list
        string result = "";
        result = GetMatchList(db, filters, page, resultsPerPage, includeMatchData != 0); 
        return result;
      }
      break;
    case CREATE_MATCH: 
      {
        // First parse everything to get the matchName, maxClients, and match data.
        string matchName;
        int maxClients;
		    vector<Filter> filters;
		    try 
	    	{
			    filters = ParseCreateMatchRequest(theRestOfTheMessage, &matchName, &maxClients);
		    }
		    catch (const string*)
		    {
			    return "";
		    }
        string result = "";
        DB::BeginTransaction(db);
        try {
          result = CreateMatch(db, socketID, matchName, maxClients, filters); 
          DB::EndTransaction(db);
        }
        catch(const std::exception& e) {
          DB::RollbackTransaction(db);
          throw e;
        }
        return result;
      }
      break;
    case DESTROY_MATCH: 
      {
        // Get the matchID to destroy
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		    if (id == LONG_MAX) return "";

        // Destroy the match
        DestroyMatch(db, id); 
        return "";
      }
      break;
    case ADD_CLIENT_TO_MATCH: 
      {
        // Get the matchID to add the client to
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		    if (id == LONG_MAX) return "";

        // Add the client, making sure to keep track of which socket they belong to
        string result = "";
        result = AddClientToMatch(db, socketID, id, true); 
        return result;
      }
      break;
    case REMOVE_CLIENT_FROM_MATCH: 
      {
        // Get the clientID of the client to remove
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		    if (id == LONG_MAX) return "";
        // Remove them
        RemoveClientFromMatch(db, id); 
        return "";
      }
      break;
    case SET_MATCH_DATA:
      {
        // Make sure data was provided
        size_t end = theRestOfTheMessage.find("|");
        if (end == string::npos) return "";
        // Get the matchID that we're setting match data for
		    string matchIDStr = theRestOfTheMessage.substr(0, end);
        long long matchID = StringUtil::try_stol(matchIDStr, "Parsing match ID");
		    if (matchID == LONG_MAX) return "";
        end++;
        // Prase the rest of the message as match data
        theRestOfTheMessage = theRestOfTheMessage.substr(end, theRestOfTheMessage.length()-end);
        vector<Filter> filters = ParseFilters(theRestOfTheMessage, false);

        DB::BeginTransaction(db);
        try {
          DeleteConflictingData(db, matchID, filters);
          DB::EndTransaction(db);
        }
        catch(const std::exception& e) {
          DB::RollbackTransaction(db);
          throw e;
        }

        // Set the match data for the match
        DB::BeginTransaction(db);
        try {
          SetMatchData(db, matchID, filters);
          DB::EndTransaction(db);
        }
        catch(const std::exception& e) {
          DB::RollbackTransaction(db);
          throw e;
        }

        return "";
      }
    default:
      return "";
  }
  
  return ""; // Not actually possible to get here but it makes a warning go away
}

string MatchUpServer::CreateMatch(sqlite3* db, int socketID, string matchName, int maxClients, vector<Filter> matchData)
{
  auto st = queryCreateMatch;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, matchName, "CreateMatch binding match name");
  DB::Bind(db, st, 2, maxClients, "CreateMatch binding maxClients");
  DB::Step(db, st, "CreateMatch creating the match");

  // Match created succesfully, add host
  long matchID = (long)sqlite3_last_insert_rowid(db);
  Debug::Log("Match created " + to_string(matchID) + " for socket id " + to_string(socketID));

  string clientIDStr = AddClientToMatch(db, socketID, matchID);
  if (clientIDStr == "") throw -1;

  // Set client as host
  long long clientID = StringUtil::try_stol(clientIDStr, "Parsing client ID");
  if (clientID == LONG_MAX) throw -1;

  SetMatchHost(db, matchID, clientID);

  // Add match data
  if (matchData.size() > 0)
  {    
    SetMatchData(db, matchID, matchData);
  }
  
  return to_string((long long)matchID) + "," + clientIDStr;
}

void MatchUpServer::SetMatchHost(sqlite3* db, long long matchID, long long clientID)
{
  sqlite3_stmt* st = querySetMatchHost;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, clientID, "SetMatchHost bind clientID");
  DB::Bind(db, st, 2, matchID, "SetMatchHost bind matchID");
  DB::Step(db, st, "SetMatchHost executing query");
}

void MatchUpServer::HandleSocketDisconnect(int socketID)
{
  DB::BeginTransaction(db);
  try {
    DestroyMatchForSocket(db, socketID);
    RemoveClientForSocket(db, socketID);
    DB::EndTransaction(db);
  }
  catch(const std::exception& e) {
    DB::RollbackTransaction(db);
    Debug::Error("Failed cleaning up disconnected client: " + string(e.what()));
  }
}

void MatchUpServer::DestroyMatchForSocket(sqlite3* db, int socketID)
{
  sqlite3_stmt* st = queryDestroyMatchForSocket;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, socketID, "DestroyMatchForSocket bind socketID");
  DB::Step(db, st, "DestroyMatchForSocket deleting match");

  Debug::Log("Destroyed match for socket ID: " + to_string((long long)socketID));
}

void MatchUpServer::RemoveClientForSocket(sqlite3* db, int socketID)
{
  sqlite3_stmt* st = queryRemoveClientForSocket;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, socketID, "RemoveClientForSocket bind socketID");
  DB::Step(db, st, "RemoveClientForSocket deleting client");

  Debug::Log("Removed Client for socket ID: " + to_string((long long)socketID));
}

void MatchUpServer::DeleteConflictingData(sqlite3* db, long long matchID, vector<Filter> matchData)
{
  for (size_t dataIndex = 0; dataIndex < matchData.size(); dataIndex++)
  {
    Filter data = matchData[dataIndex];

    sqlite3_stmt *st;
    switch (data.valueType)
    {
      case Filter::INT: st = queryDeleteIntData; break;
      case Filter::FLOAT: st = queryDeleteFloatData; break;
      case Filter::STRING: st = queryDeleteStringData; break;
      default: Debug::Log("Unrecognized filter type"); throw -1; 
    }
    sqlite3_reset(st);

    DB::Bind(db, st, 1, matchID, "DeleteConflictingMatchData binding matchID");
    DB::Bind(db, st, 2, data.key, "DeleteConflictingMatchData binding key: " + data.key);
    DB::Step(db, st, "DeleteConflictingMatchData executing query");
  }
}

void MatchUpServer::SetMatchData(sqlite3* db, long long matchID, vector<Filter> matchData)
{
  for (size_t dataIndex = 0; dataIndex < matchData.size(); dataIndex++)
  {
    Filter data = matchData[dataIndex];

    sqlite3_stmt *st;
    switch (data.valueType)
    {
      case Filter::INT: st = queryInsertIntData; break;
      case Filter::FLOAT: st = queryInsertFloatData; break;
      case Filter::STRING: st = queryInsertStringData; break;
      default: Debug::Log("Unrecognized filter type"); throw -1; 
    }
    sqlite3_reset(st);

    DB::Bind(db, st, 1, matchID, "SetMatchData binding matchID");
    DB::Bind(db, st, 2, data.key, "SetMatchData binding key");
    switch(data.valueType)
    {
      case Filter::STRING:
        DB::Bind(db, st, 3, data.stringValue, "SetMatchData binding string value");
        break;
      case Filter::FLOAT:
        DB::Bind(db, st, 3, data.floatValue, "SetMatchData binding float value");
        break;
      case Filter::INT:
        DB::Bind(db, st, 3, data.intValue, "SetMatchData binding int value");
        break;
    }
    DB::Step(db, st, "SetMatchData fetching results");
  }
}

string MatchUpServer::AddClientToMatch(sqlite3* db, int socketID, long long matchID, bool includeMatchData)
{
  sqlite3_stmt* st = queryAddClientToMatch;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, matchID, "AddClientToMatch binding matchID");
  DB::Bind(db, st, 2, socketID, "AddClientToMatch binding socketID");
  DB::Step(db, st, "AddClientToMatch fetching results");

  sqlite_int64 clientID = sqlite3_last_insert_rowid(db);
  string responseText = to_string((long long)clientID);

  Debug::Log("Added client " + to_string((long long)clientID) + " to match " + to_string((long long)matchID));

  if (includeMatchData)
  {
    string matchDataString = "";
    int numDatas = 0;
  
    EncodeMatchData(db, matchID, Filter::INT, &numDatas, matchDataString);
    EncodeMatchData(db, matchID, Filter::FLOAT, &numDatas, matchDataString);
    EncodeMatchData(db, matchID, Filter::STRING, &numDatas, matchDataString);
  
    if (numDatas > 0)
    {
      responseText += "," + to_string((long long)numDatas);
      responseText += "|";
      responseText += matchDataString;
      responseText = responseText.substr(0, responseText.length()-1);
    }
  }
  return responseText;
}

void MatchUpServer::DestroyMatch(sqlite3* db, long long matchID)
{
  auto st = queryDestroyMatch;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, matchID, "DestroyMatch binding matchID");
  DB::Step(db, st, "DestroyMatch executing sql");

  Debug::Log("Destroyed match " + to_string((long long)matchID));
}

void MatchUpServer::RemoveClientFromMatch(sqlite3* db, long long clientID)
{
  auto st = queryRemoveClientFromMatch;
  sqlite3_reset(st);

  DB::Bind(db, st, 1, clientID, "RemoveClientFromMatch binding clientID");
  DB::Step(db, st, "RemoveClientFromMatch executing sql");

  Debug::Log("Removed client " + to_string((long long)clientID));
}

vector<Filter> MatchUpServer::ParseFilters(string matchDataString, bool isFilter)
{
  vector<Filter> filters;
  if (matchDataString == "") return filters;
  size_t startPos = 0;
  size_t endPos = matchDataString.find(",", startPos);
  while (endPos != string::npos && endPos < matchDataString.length())
  {
    // Value type
    endPos = matchDataString.find(",", startPos);
	  string filterValueTypeStr = matchDataString.substr(startPos, endPos - startPos);
	  long long filterValueTypeInt = StringUtil::try_stol(filterValueTypeStr, "Parsing filter value type");
	  if (filterValueTypeInt == LONG_MAX) return filters;
	  Filter::ValueType type = (Filter::ValueType)filterValueTypeInt;
	  startPos = endPos + 1;

    // Key
	  endPos = matchDataString.find(",", startPos);
	  string key = matchDataString.substr(startPos, (endPos-startPos));
	  startPos = endPos + 1;

    // Value
	  string valueText;
	  if (type == Filter::STRING)
	  {
      valueText = StringUtil::parseQuoted(matchDataString, startPos, &endPos);

      if (endPos == string::npos)
	    {
	      vector<Filter> filters;
	      return filters;
	    }
	    startPos = endPos + 1;
	  }
	  else
	  {
      if (isFilter)
      {
	      endPos = matchDataString.find(",", startPos);
      }
      else
      {
	      endPos = matchDataString.find("|", startPos);
      }
	    if (endPos == string::npos) endPos = matchDataString.length();
	    valueText = matchDataString.substr(startPos, (endPos-startPos));
	    startPos = endPos + 1;
	  }
	 
	  Filter::Operation op = Filter::EQUALS;
	  if (isFilter)
	  {
	    endPos = matchDataString.find("|", startPos);
	    if (endPos == string::npos) endPos = matchDataString.length();
	    string operationString = matchDataString.substr(startPos, endPos-startPos);
      startPos = endPos + 1; // for the pipe
	    long long operationInt = StringUtil::try_stol(operationString, "Parsing operation string");
	    if (operationInt == LONG_MAX) return filters;
	    op = (Filter::Operation)operationInt;
	    // Skip invalid filter combination
	    if (op == Filter::LIKE && type != Filter::STRING)
	    {
	      continue;
	    }
	  }
	  try
	  {
		  Filter filter(key, valueText, op, type);
		  filters.push_back(filter);
	  }
	  catch (const string& e)
	  {
		  cerr << e << endl;
	  }
  } 

  return filters;
}

vector<Filter> MatchUpServer::ParseCreateMatchRequest(string matchDataString, string* matchName, int* maxPlayers)
{
  size_t startPos = 0;
  size_t endPos = 0;
  
  *matchName = StringUtil::parseQuoted(matchDataString, startPos, &endPos);
  
  startPos = endPos + 1;
  endPos = matchDataString.find("|", startPos);
  if (endPos == string::npos)
  {
    endPos = matchDataString.length();
  }
  string maxPlayersStr = matchDataString.substr(startPos, endPos - startPos);
  long long maxPlayersInt = StringUtil::try_stol(maxPlayersStr, "Parsing max players");
  if (maxPlayersInt == LONG_MAX) throw string("Failed parsing create match request");
  *maxPlayers = (int)maxPlayersInt;
  
  vector<Filter> filters;

  if (endPos != matchDataString.length())
  {
    string theRestOfTheString = matchDataString.substr(endPos+1);
    filters= MatchUpServer::ParseFilters(theRestOfTheString, false);
  }
  return filters;
}

string MatchUpServer::GetMatch(sqlite3* db, long long matchID)
{
  auto st = queryGetMatch;
  sqlite3_reset(st);

	DB::Bind(db, st, 1, matchID, "GetMatch binding filter key");

	int resultCode;
	DB::Step(db, st, "GetMatch fetching results", &resultCode);

	string responseText = "";
	if (resultCode == SQLITE_ROW)
	{	
		string encodedData = "";
		int numDatas = 0;

		responseText += to_string(matchID);

		EncodeMatchData(db, matchID, Filter::INT, &numDatas, encodedData);
		EncodeMatchData(db, matchID, Filter::FLOAT, &numDatas, encodedData);
		EncodeMatchData(db, matchID, Filter::STRING, &numDatas, encodedData);

		if (numDatas > 0)
		{
			responseText += "," + to_string((long long)numDatas);
			responseText += "|";
			responseText += encodedData;
		}
	}

	// Remove trailing pipe
	responseText.erase(responseText.length() - 1, 1);
	return responseText;
}

string MatchUpServer::GetMatchList(sqlite3* db, vector<Filter> filters, long long page, long long resultsPerPage, bool includeMatchData)
{
  DB::Exec(db, "DELETE FROM FilteredMatches", "Clearing filtered matches");

  // Query to get the filtered match list
  // Results are used to populate the FilteredMatches table so that we can do
  // further processing to get the match data for each match.
  string q = "INSERT INTO FilteredMatches SELECT NULL, ID, 0, '' FROM Matches";
  // Each filter results in an additional join to one of the Data tables
  string filterStrTemplate = " JOIN [table] AS [alias] ON [alias].matchID = Matches.id AND [alias].key = ? AND [alias].value [op] ?";
  for (size_t i = 0; i < filters.size(); i++)
  {
    Filter filter = filters[i];
    string tableName = Filter::TYPE_TABLES[(int)filter.valueType];
    string alias = "f" + to_string(i);
    string operation = Filter::OPS[filter.operation];

    string filterStr = filterStrTemplate;
    StringUtil::Replace(filterStr, "[table]", tableName);
    StringUtil::Replace(filterStr, "[alias]", alias);
    StringUtil::Replace(filterStr, "[op]", operation);
    q += filterStr;
  }
  // Don't return matches that are full
  q += " WHERE maxClients > ("
    " SELECT COUNT(*)"
    " FROM Clients"
    " WHERE Clients.matchID = Matches.id "
    ") "
    "ORDER BY Matches.id DESC LIMIT ?, ?";

  sqlite3_stmt *st;
  DB::Prep(db, &st, q, "GetMatchList preparing filter statementa");

  // Bind the key and value for each filter in the query
  int i = 1;
  for (size_t filterIndex = 0; filterIndex < filters.size(); filterIndex++)
  {
    Filter filter = filters[filterIndex];
    DB::Bind(db, st, i, filter.key, "GetMatchList binding filter key", true);
    i++;

    switch(filter.valueType)
    {
      case Filter::STRING:
        {
          string stringVal = filter.stringValue;
          if (filter.operation == Filter::LIKE) stringVal = "%" + stringVal + "%";
          DB::Bind(db, st, i, stringVal, "GetMatchList binding filter string value", true);
        }
        break;
      case Filter::FLOAT:
        DB::Bind(db, st, i, filter.floatValue, "GetMatchList binding filter float value", true);
        break;
      case Filter::INT:
        DB::Bind(db, st, i, filter.intValue, "GetMatchList binding filter int value", true);
        break;
    }
    i++;
  }

  // Pagination
  DB::Bind(db, st, i, page*resultsPerPage, "GetMatchList bind offset", true);
  i++;
  DB::Bind(db, st, i, resultsPerPage, "GetMatchList bind limit", true);
  i++;

  // Execute the query and populate the FilteredMatches table
  DB::Step(db, st, "GetMatchList populating filtered results table", NULL, true);

  sqlite3_finalize(st);

  // Populate matchData column for each match in the FilteredMatches table
  sqlite3_reset(queryUpdateFilteredMatchData);
  DB::Step(db, queryUpdateFilteredMatchData, "Updated filtered match data");

  // Get the list of matches including match data all as one long string
  string responseText = "";
  int resultCode;
  sqlite3_reset(querySelectFilteredMatches);
  DB::Step(db, querySelectFilteredMatches, "GetMatchList fetching sorted results", &resultCode);
  if (resultCode == SQLITE_ROW)
  {
    auto theGoodStuff = sqlite3_column_text(querySelectFilteredMatches, 0);
    // If filtered match list is empty this will be nullptr
    if (theGoodStuff != nullptr)
    {
      responseText = (char*)sqlite3_column_text(querySelectFilteredMatches, 0);
    }
  }
 
  return responseText;
}

void MatchUpServer::EncodeMatchData(sqlite3* db, long long matchID, Filter::ValueType type, int* numDatas, string& encodedString)
{
  sqlite3_stmt *st;
  switch (type)
  {
    case Filter::ValueType::INT: st = queryGetIntData; break;
    case Filter::ValueType::FLOAT: st = queryGetFloatData; break;
    case Filter::ValueType::STRING: st = queryGetStringData; break;
    default: Debug::Log("Unrecognized filter type"); throw -1; 
  }
  sqlite3_reset(st);

  DB::Bind(db, st, 1, matchID, "EncodeMatchData binding matchID");

  string typeAsString = to_string((int)type);

  //string encodedString;
  while(true)
  {
    int result;
    DB::Step(db, st, "EncodeMatchData fetching results", &result);

    if (result == SQLITE_ROW)
    {
      encodedString += typeAsString;
      encodedString += ",";

      string key = (char*)sqlite3_column_text(st, 0);
      encodedString += key;
      encodedString += ",";

      switch (type)
      {
        case Filter::INT:
          encodedString += to_string((long long)sqlite3_column_int64(st, 1));
          break;
        case Filter::FLOAT:
          encodedString += to_string((double)sqlite3_column_double(st, 1));
          break;
        case Filter::STRING:
          encodedString += "\"";
          encodedString += string((char*)sqlite3_column_text(st, 1));
          encodedString += "\"";
          break;
      }
      encodedString += "|";
      *numDatas = *numDatas + 1;
    }
    else if (result == SQLITE_DONE)
    {
      break;
    }
  }
}
