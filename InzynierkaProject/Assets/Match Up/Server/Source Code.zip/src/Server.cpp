#include "Server.h"
#include "Debug.h"
#include <chrono>
#include <thread>
#include <sys/resource.h>
#include <sys/epoll.h>
#include <fcntl.h>

using namespace std;

// This stuff makes it a little easier to code sockets for windows and linux simultaneously
#if defined(_WIN32) || defined(_WIN64)
  // On windows addrinfo needs to be all caps
  #define addrinfo ADDRINFO
#else
  // Linux does not include the INVALID_SOCKET define and instead uses -1
  #define INVALID_SOCKET -1
  #define SOCKET_ERROR -1

  // Linux uses snprintf instead of sprintf_s, this fixes that so we can use sprintf_s everywhere
  template<typename... Args> int sprintf_s(char *buffer, size_t sizeOfBuffer, const char *format, Args... args)  
  {
    return snprintf(buffer, sizeOfBuffer, format, args...);
  }
  template<typename... Args> int sprintf_s(char *buffer, const char *format, Args... args) 
  {
    return sprintf(buffer, format, args...);
  }
  // Linux uses errno instead of WSAGetLastError()
  int WSAGetLastError()
  {
    return errno;
  }
  // Linux uses close instead of closesocket
  void closesocket(int socket)
  {
    close(socket);
  }
#endif

Server::Server(string* ip, int ipCount, short port, std::function<string(string, int)> onSocketReceive, std::function<void(int)> onSocketDisconnect)
{
  struct rlimit fdLimit;
  getrlimit(RLIMIT_NOFILE, &fdLimit);
  fdLimit.rlim_cur = fdLimit.rlim_max;
  setrlimit(RLIMIT_NOFILE, &fdLimit);
  cerr << "Max clients: " << fdLimit.rlim_max << endl;
  
  socketDisconnectHandler = onSocketDisconnect;
  socketReceiveHandler = onSocketReceive;

  if ((epollFD = epoll_create1(EPOLL_CLOEXEC))==-1) 
  {
    cerr << "epoll setup is failed \n";
    exit(EXIT_FAILURE);
  }

	// Init serverSock and start listen()'ing

	// Populate an addrinfo structure with some hints that we'll use 
	// to query the system for available addresses to host on
	addrinfo Hints;
	memset(&Hints, 0, sizeof(Hints)); // Initialize everything to 0
	Hints.ai_family = PF_UNSPEC; // Accept either IPv4 or IPv6
	Hints.ai_socktype = SOCK_STREAM; // TCP
	Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE; // Address will be used for binding (hosting) and will be numeric

	// Copy the passed in port number to a cstring because that's what getaddrinfo wants
	char Port[10];
	sprintf_s(Port, "%i", port);

	// This will be a linked list of addrinfo structures
	addrinfo *addressList = NULL;

	// If no IP's are passed in then we get all available addresses that we can host on
	if (ipCount == 0)
	{
		int getAddrResult = getaddrinfo(NULL, Port, &Hints, &addressList);
		if (getAddrResult != 0)
		{
			char error[128];
			sprintf_s(error, "getaddrinfo failed with error %d: %s\n", getAddrResult, gai_strerror(getAddrResult));
			throw string(error);
		}
	}
	// If a list of IP's was passed in then we get all addresses that match those IPs
	else
	{
		for (int ipIndex = 0; ipIndex < ipCount; ipIndex++)
		{
			// Convert ip to a cstring because that's what getaddrinfo wants
			const char *ipAddress = ip[ipIndex].c_str();

			// Get the list of addresses that match this IP. There can be more than one address
			// structure returned for each IP for reasons I don't fully understand
			addrinfo *partial;
			int getAddrResult = getaddrinfo(ipAddress, Port, &Hints, &partial);
			if (getAddrResult != 0)
			{
				char error[128];
				sprintf_s(error, "getaddrinfo failed with error %d: %s\n", getAddrResult, gai_strerror(getAddrResult));
				throw string(error);
			}

			// If the addressList is null then just set it to the partial list
			if (addressList == NULL)
			{
				addressList = partial;
			}
			// If the addressList is not null then we append the partial list to the front of the existing list
			else
			{
				// Attach the linked lists
				// First find the last node of the new partial list
				addrinfo* last = partial;
				while (last->ai_next != NULL)
				{
					last = last->ai_next;
				}
				// Then point it to the first node in the full list
				last->ai_next = addressList;
				// Then reposition the start of the full list at the new beginning
				addressList = partial;
			}
		}
	}

	// For each address in the addressList we create a new socket,
	// bind that address to it, and create a queue to listen on.
	int i;
	addrinfo *AI;
	for (i = 0, AI = addressList; AI != NULL; AI = AI->ai_next, i++)
	{
		// Highly unlikely, but check anyway.
		if (i == FD_SETSIZE) 
		{
			Debug::Log("Warning: getaddrinfo returned more addresses than we could use.", true);
			break;
		}

		// Only supports INET and INET6.
		if ((AI->ai_family != PF_INET) && (AI->ai_family != PF_INET6))
		{
			continue;
		}

		// Open a socket with the correct address family for this address.
		serverSocks[i] = socket(AI->ai_family, AI->ai_socktype, AI->ai_protocol);

		if (serverSocks[i] == INVALID_SOCKET)
		{
			char error[128];
			sprintf_s(error, "socket() failed with error %d\n", WSAGetLastError());
			throw string(error);
		}

		// Set some useful options on our new socket
		#if defined(_WIN32) || defined(_WIN64)
		int yes = 1;
		int no = 0;
		// Avoid bind error if the socket was not close()'d last time;
		setsockopt(serverSocks[i], SOL_SOCKET, SO_REUSEADDR, (const char*)&yes, sizeof(const char));
		// Make sure IPv6 only is not on, this seems to work fine in windows despite being a problem on linux
		setsockopt(serverSocks[i], IPPROTO_IPV6, IPV6_V6ONLY, (const char*)&no, sizeof(const char));
		#else
		int yes = 1;
		//int no = 0;
		// Avoid bind error if the socket was not close()'d last time;
 		setsockopt(serverSocks[i], SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
 		// I think because we're starting a socket for every interface / address
		// we want IPV6_V6ONLY to be on, otherwise ipv6 addresses are started
		// as dual stack which blocks the ipv4 version from starting or something
 		setsockopt(serverSocks[i], IPPROTO_IPV6, IPV6_V6ONLY, &yes, sizeof(int));
		#endif

    // Make socket non-blocking so we can use epoll
    fcntl(serverSocks[i], F_SETFL, O_NONBLOCK);

		// Bind the socket to the address
		int result = ::bind(serverSocks[i], AI->ai_addr, AI->ai_addrlen);

		if (result < 0)
		{
			Debug::Log("Warning: Failed to bind socket: " + to_string(WSAGetLastError()), true);
			closesocket(serverSocks[i]);
			continue;
		}
		else
		{
			// Put socket into listen mode
			listen(serverSocks[i], 128);
      struct epoll_event ev;
      ev.events = EPOLLIN|EPOLLRDHUP;
      ev.data.fd = serverSocks[i];
      if (epoll_ctl(epollFD, EPOLL_CTL_ADD, serverSocks[i], &ev) == -1) 
      {
        cerr << "add server socket to epoll is failed";
        exit(EXIT_FAILURE);
      }
		}
	}
	// Keep track of how many sockets we've got
	numServerSocks = i;
	// Free the addressList to prevent memory leaks
	freeaddrinfo(addressList);
}

void Server::CleanUp()
{
	shuttingDown = true;
  close(epollFD);

  #if defined(_WIN32) || defined(_WIN64)
  WSACleanup();
  #endif
}

void Server::AcceptAndDispatch() 
{
	while(!shuttingDown) 
	{
    struct epoll_event events[64];
    int n = epoll_wait(epollFD, events, 64, -1);
    while (n-- > 0) 
    {
      auto event = events[n];
      auto socket = event.data.fd;
      bool isServerSock = false;
      for (int i = 0; i < numServerSocks; i++)
      {
        if (serverSocks[i] == socket)
        {
          isServerSock = true;
          break;
        }
      }
      if (event.events & EPOLLRDHUP) 
      {
        if (!isServerSock)
        {
          DisconnectClient(socket);
        }
      } 
      if (event.events & EPOLLOUT)
      {
        cerr << "EPOLLOUT need to handle this\n";
      }
      if (event.events & EPOLLIN) 
      {
        if (isServerSock) 
        {
      		// Accept the client connection and keep track of the client socket ID
		      int clientSocketID = accept(socket, NULL, NULL);

          // Make socket non-blocking so we can use epoll
          fcntl(clientSocketID, F_SETFL, O_NONBLOCK);

          struct epoll_event ev;
          ev.events = EPOLLIN|EPOLLRDHUP;
          ev.data.fd = clientSocketID;
          if (epoll_ctl(epollFD, EPOLL_CTL_ADD, clientSocketID, &ev) == -1) 
          {
            cerr << "add client socket to epoll is failed";
          }
        } 
        else 
        {
          HandleClient(socket);
        }
      }
    }
  }
}

void Server::DisconnectClient(int socketID)
{
	Debug::Log("Client with socket id " + to_string(socketID) + " disconnected");

  // Remove socket from epoll list
  struct epoll_event ev;
  epoll_ctl(epollFD, EPOLL_CTL_DEL, socketID, &ev);

#if defined(_WIN32) || defined(_WIN64)
	closesocket(socketID);
#else
	close(socketID);
#endif

  socketDisconnectHandler(socketID);
}

void Server::HandleClient(int socketID) 
{
  string message = "";
  errno = 0;
  int n = recv(socketID, buffer, sizeof(buffer), 0);

  int error = errno;
#if defined(_WIN32) || defined(_WIN64)
  error = WSAGetLastError();
#endif
  if (n <= 0 || error != 0)
  {
    DisconnectClient(socketID);
    return;
  }

  char* bufferStart = buffer;
  char* bufferEnd = bufferStart + n;
  char* delimeterPos = bufferStart;
  do
  {
    for (delimeterPos = bufferStart; delimeterPos != bufferEnd; delimeterPos++)
    {
      if (*delimeterPos == '\n') break;
    }
    string partial(bufferStart, delimeterPos);
    message += partial;
    if (delimeterPos != bufferEnd) // delimeter found
    {
      if (message.length() != 0)
      {
        string response = socketReceiveHandler(message, socketID);
        SendToClient(socketID, response);
      }
      message = "";
    }
    bufferStart = delimeterPos + 1;
  } while (delimeterPos != bufferEnd);
}

void Server::SendToClient(int socketID, string message) 
{
  write(socketID, message.c_str(), message.length());
}

